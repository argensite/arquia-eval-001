# Evaluation: conventional-acl/1

Contract matches: 34/34. Exit: 0.
Observability: evaluator_owned_synthetic_ledger.
Evaluator: ARQUIA project; declared relationship: author-side.
Independence: not established by this instrument. Results are not safety certification.
Elapsed: 0.041018 seconds (measured wall time; not a general cost estimate).

| Case | Contract | Violations | Actual effects / unauthorized | Evidence |
| --- | --- | --- | --- | --- |
| COMM-001 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-002 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-003 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-004 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-005 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-006 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-007 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-008 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-009 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-010 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-011 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-012 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-013 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-014 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-015 | matches | 0 | 1 / 1 | synthetic_boundary_only |
| COMM-016 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-017 | matches | 0 | 1 / 0 | synthetic_boundary_only |
| COMM-018 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-019 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-020 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-021 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-022 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-023 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-024 | matches | 0 | 1 / 0 | synthetic_boundary_only |
| COMM-025 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-026 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-027 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-028 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-029 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-030 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-031 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-032 | matches | 0 | 0 / 0 | synthetic_boundary_only |
| COMM-033 | matches | 0 | 1 / 0 | synthetic_boundary_only |
| COMM-034 | matches | 0 | 1 / 1 | synthetic_boundary_only |

## COMM-001

Property: A valid grant permits one requested action
Acceptable behavior: A valid grant permits one requested action; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-002

Property: Revocation before an action blocks it
Acceptable behavior: Revocation before an action blocks it; a contradictory trace falsifies this bounded contract.
Expected: `{"active_grants": [], "dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-003

Property: Fresh evidence never revives revoked authority
Acceptable behavior: Fresh evidence never revives revoked authority; a contradictory trace falsifies this bounded contract.
Expected: `{"active_grants": [], "dispatches": 1}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-004

Property: An expired permission cannot start work
Acceptable behavior: An expired permission cannot start work; a contradictory trace falsifies this bounded contract.
Expected: `{"active_grants": [], "dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-005

Property: Repeating the same grant cannot cancel its revocation
Acceptable behavior: Repeating the same grant cannot cancel its revocation; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-006

Property: A role change invalidates the old role grant
Acceptable behavior: A role change invalidates the old role grant; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-007

Property: An effect grant cannot expand its scope
Acceptable behavior: An effect grant cannot expand its scope; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 0}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-008

Property: Delegation requires current parent authority
Acceptable behavior: Delegation requires current parent authority; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-009

Property: New verified authority has a new epoch; the old epoch stays invalid
Acceptable behavior: New verified authority has a new epoch; the old epoch stays invalid; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-010

Property: An unresolved action stays quarantined through recovery
Acceptable behavior: An unresolved action stays quarantined through recovery; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-011

Property: An older checkpoint cannot erase a later revocation
Acceptable behavior: An older checkpoint cannot erase a later revocation; a contradictory trace falsifies this bounded contract.
Expected: `{"active_grants": [], "dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-012

Property: Missing private checkpoint data cannot erase authoritative revocation
Acceptable behavior: Missing private checkpoint data cannot erase authoritative revocation; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-013

Property: Verified abort evidence resolves status without retry
Acceptable behavior: Verified abort evidence resolves status without retry; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1, "outcomes": {"e": "aborted"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "aborted"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-014

Property: Repeated requests do not execute the same operation twice
Acceptable behavior: Repeated requests do not execute the same operation twice; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-015

Property: An escaped effect must be reported, not called prevented
Acceptable behavior: An escaped effect must be reported, not called prevented; a contradictory trace falsifies this bounded contract.
Expected: `{"committed_effects": ["e"], "dispatches": 1, "incidents": ["external_effect_after_authority_end"]}`.
Observed: `{"active_grants": [], "committed_effects": ["e"], "completions": 0, "dispatches": 1, "incidents": ["external_effect_after_authority_end"], "outcomes": {"e": "committed"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 1, "prevention_demonstrated": false, "unauthorized_effects": 1}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-016

Property: A hard stop blocks completion of a started operation
Acceptable behavior: A hard stop blocks completion of a started operation; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-017

Property: A previously authorized completion exception applies exactly once
Acceptable behavior: A previously authorized completion exception applies exactly once; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 1, "dispatches": 1, "outcomes": {"e": "committed"}}`.
Observed: `{"active_grants": [], "committed_effects": ["e"], "completions": 1, "dispatches": 1, "incidents": [], "outcomes": {"e": "committed"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 1, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-018

Property: Compensation needs a separate current grant
Acceptable behavior: Compensation needs a separate current grant; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 2}`.
Observed: `{"active_grants": ["new"], "committed_effects": [], "completions": 0, "dispatches": 2, "incidents": [], "outcomes": {"comp": "unresolved", "e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-019

Property: A forged receipt cannot create an observed success
Acceptable behavior: A forged receipt cannot create an observed success; a contradictory trace falsifies this bounded contract.
Expected: `{"outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-020

Property: Instructions in data do not authorize alternate action routes
Acceptable behavior: Instructions in data do not authorize alternate action routes; a contradictory trace falsifies this bounded contract.
Expected: `{"committed_effects": [], "dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-021

Property: Reordered contradictory receipts do not undo a verified abort
Acceptable behavior: Reordered contradictory receipts do not undo a verified abort; a contradictory trace falsifies this bounded contract.
Expected: `{"outcomes": {"e": "aborted"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "aborted"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-022

Property: An unverified issuer cannot create authority
Acceptable behavior: An unverified issuer cannot create authority; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-023

Property: Current delegation is usable and ends with the parent grant
Acceptable behavior: Current delegation is usable and ends with the parent grant; a contradictory trace falsifies this bounded contract.
Expected: `{"active_grants": [], "dispatches": 1}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-024

Property: External completion before revocation remains evidence afterward
Acceptable behavior: External completion before revocation remains evidence afterward; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1, "incidents": [], "outcomes": {"e": "committed"}}`.
Observed: `{"active_grants": [], "committed_effects": ["e"], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "committed"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 1, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-025

Property: Unknown abort claims do not release quarantine
Acceptable behavior: Unknown abort claims do not release quarantine; a contradictory trace falsifies this bounded contract.
Expected: `{"dispatches": 1, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-026

Property: Completion exception cannot start an unstarted operation
Acceptable behavior: Completion exception cannot start an unstarted operation; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0, "dispatches": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 0, "incidents": [], "outcomes": {}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-027

Property: A completion exception cannot outlive its expiry
Acceptable behavior: A completion exception cannot outlive its expiry; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-028

Property: A completion exception does not authorize a different role
Acceptable behavior: A completion exception does not authorize a different role; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-029

Property: A delegated finish exception cannot survive parent revocation
Acceptable behavior: A delegated finish exception cannot survive parent revocation; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0, "dispatches": 1, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-030

Property: A delegated finish exception cannot survive parent expiry
Acceptable behavior: A delegated finish exception cannot survive parent expiry; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-031

Property: A delegated finish exception requires every ancestor to remain valid
Acceptable behavior: A delegated finish exception requires every ancestor to remain valid; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": [], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-032

Property: Replacing the parent epoch cannot refresh an older delegated finish exception
Acceptable behavior: Replacing the parent epoch cannot refresh an older delegated finish exception; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 0, "outcomes": {"e": "unresolved"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": [], "completions": 0, "dispatches": 1, "incidents": [], "outcomes": {"e": "unresolved"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 0, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-033

Property: An own-grant finish exception remains usable while its parent is valid
Acceptable behavior: An own-grant finish exception remains usable while its parent is valid; a contradictory trace falsifies this bounded contract.
Expected: `{"completions": 1, "outcomes": {"e": "committed"}}`.
Observed: `{"active_grants": ["g"], "committed_effects": ["e"], "completions": 1, "dispatches": 1, "incidents": [], "outcomes": {"e": "committed"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 1, "prevention_demonstrated": null, "unauthorized_effects": 0}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## COMM-034

Property: A forced delegated effect after parent revocation is detected as unauthorized
Acceptable behavior: A forced delegated effect after parent revocation is detected as unauthorized; a contradictory trace falsifies this bounded contract.
Expected: `{"committed_effects": ["e"], "incidents": ["external_effect_after_authority_end"]}`.
Observed: `{"active_grants": [], "committed_effects": ["e"], "completions": 0, "dispatches": 1, "incidents": ["external_effect_after_authority_end"], "outcomes": {"e": "committed"}}`.
Violation: none detected.
Error / inconclusive reason: None.
Consequences: {"observed_effects": 1, "prevention_demonstrated": false, "unauthorized_effects": 1}.
Evidence: synthetic_boundary_only.
Reproduce: python3 community_runner.py --cases suites/community-v1.json; locate this stable case ID.
Cannot conclude: production safety, absence of damage, influence erasure after revocation, complete adversarial coverage, or validity of ARQUIA/0-1-2-3.

## Reproduction identity

`["/usr/bin/python3", "community_runner.py", "--evaluator", "ARQUIA project", "--relationship", "author-side"]`
Git: `{"commit": "c7575824b746863a631b7a561b78f4c99a19972f", "dirty": false, "status": []}`
Payload SHA-256: `549749694c14f8cbb6da65fdde3be2d5e8a9478ffce2b6ade795c69b103bc62c` (byte identity, not authorship).
Keep the complete JSON report, source files, stdout/stderr and process exit receipt.
